#!/bin/bash
#
# @CreationTime
#   2020/1/6 下午14:14:25
# @ModificationDate
#   2020/1/6 下午14:14:25
# @Function
#  启动 arthas
#  如果只是退出当前的连接，可以用quit或者exit命令。Attach到目标进程上的arthas还会继续运行，端口会保持开放，下次连接时可以直接连接上。
#  如果想完全退出arthas，可以执行stop/shutdown命令。
# @Usage
#
#
# @author Siu

java -jar ./arthas-boot.jar