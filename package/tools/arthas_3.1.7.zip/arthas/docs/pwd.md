pwd
===

> 返回当前的工作目录，和linux命令类似


```bash
$ pwd
```