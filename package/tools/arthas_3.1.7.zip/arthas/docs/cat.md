cat
===

> 打印文件内容，和linux里的cat命令类似。


```bash
$ cat /tmp/a.txt
```