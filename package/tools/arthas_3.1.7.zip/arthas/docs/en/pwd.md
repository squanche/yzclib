pwd
===

> Return working directory name


```bash
$ pwd
```