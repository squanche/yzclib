cat
===

> Concatenate and print files


```bash
$ cat /tmp/a.txt
```